﻿Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class Form1

    Dim paramName As String = "param.dat"

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim frm As New Form2()
        frm.ShowDialog()
        Me.Show()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim obj = BinDeserializa()
        Dim params As String() = obj.ToString.Split(";")
        Dim items As String()
        For Each item In params

            If item.Contains("user") Then

                items = item.Split(":")
                Me.TextBox1.Text = items(1)

            ElseIf item.Contains("lang") Then
                items = item.Split(":")
                Me.TextBox2.Text = items(1)
            End If

        Next

    End Sub

    Private Function BinDeserializa() As Object
        Dim obj As New Object
        Dim ph As String = IO.Path.GetFullPath("..\..\..\..\") & paramName
        If File.Exists(ph) = False Then
            Return Nothing
        End If

        Dim fs As New FileStream(ph, FileMode.Open)
        Dim formatter As New BinaryFormatter

        Try

            obj = formatter.Deserialize(fs)

        Catch ex As Exception

        Finally
            fs.Close()
        End Try

        Return obj

    End Function

End Class
