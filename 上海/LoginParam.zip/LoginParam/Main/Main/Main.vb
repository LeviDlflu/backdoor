﻿Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Security.Cryptography

Public Class Main

    Dim proc As Process
    Dim paramName As String = "param.dat"
    Dim keyIV As Byte() = {1, 2, 4, 6, 7, 3, 1, 5}

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim path As String = IO.Path.GetFullPath("..\..\..\Master")

        proc = New Process

        Dim exepath As String = path & "\bin\Debug\Master.exe"
        Dim filestartinfo As ProcessStartInfo = New ProcessStartInfo(exepath)
        proc.StartInfo = filestartinfo
        proc.Start()

    End Sub

    Private Sub Main_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        If proc.HasExited = False Then
            proc.CloseMainWindow()
            proc.Dispose()
        End If

    End Sub

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim obj = DecryptDes(BinDeserializa())

        Dim params As String() = obj.Split(";")
        Dim items As String()

        For Each item In params

            If item.Contains("user") Then

                items = item.Split(":")
                Me.TextBox1.Text = items(1)

            ElseIf item.Contains("lang") Then
                items = item.Split(":")
                Me.TextBox2.Text = items(1)
            End If

        Next

    End Sub

    Private Function BinDeserializa() As Object
        Dim obj As New Object
        Dim ph As String = IO.Path.GetFullPath("..\..\..\..\") & paramName
        If File.Exists(ph) = False Then
            Return Nothing
        End If

        Dim fs As New FileStream(ph, FileMode.Open)
        Dim formatter As New BinaryFormatter

        Try

            obj = formatter.Deserialize(fs)

        Catch ex As Exception

        Finally
            fs.Close()
        End Try

        Return obj

    End Function

    Public Function DecryptDes(ByVal strToDecrypt As String) As String
        Dim result As String
        Dim des As New DESCryptoServiceProvider

        des.Key = keyIV

        des.IV = keyIV

        Dim buffer As Byte() = Convert.FromBase64String(strToDecrypt)

        Dim ms As New MemoryStream(buffer)

        Dim encStream As New CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Read)

        Dim sr As New StreamReader(encStream)

        result = Convert.ToBase64String(ms.ToArray)
        result = sr.ReadLine
        sr.Close()
        encStream.Close()
        ms.Close()

        Return result

    End Function

End Class