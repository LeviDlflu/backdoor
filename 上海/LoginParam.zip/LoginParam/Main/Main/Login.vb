﻿Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Security.Cryptography
Imports System.Text

Public Class Login

    Dim paramName As String = "param.dat"
    Dim keyIV As Byte() = {1, 2, 4, 6, 7, 3, 1, 5}
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try

            Dim str As String = "user:" & Me.TextBox1.Text & ";pwd:" & Me.TextBox2.Text & ";lang:" & Me.ComboBox1.Text

            BinSeralize(EncryptDes(str))

        Catch ex As Exception

        End Try

        Dim frm As New Main()
        frm.ShowDialog()
        Me.Show()

    End Sub

    Private Sub BinSeralize(ByVal binSer As String)
        Dim ph As String = IO.Path.GetFullPath("..\..\..\..\") & paramName
        Dim fs As New FileStream(ph, FileMode.OpenOrCreate)
        Dim bf As New BinaryFormatter

        Try
            bf.Serialize(fs, binSer)
        Catch ex As Exception

        Finally
            fs.Close()
        End Try

    End Sub

    Private Sub Login_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim ph As String = IO.Path.GetFullPath("..\..\..\..\") & paramName

        If File.Exists(ph) = False Then
            Return
        End If

        Try

            File.Delete(ph)

        Catch ex As Exception

        End Try
    End Sub

    Public Function EncryptDes(ByVal SourceStr As String) As String

        Dim des As New DESCryptoServiceProvider

        Dim inputByteArray As Byte()

        inputByteArray = Encoding.Default.GetBytes(SourceStr)

        des.Key = keyIV

        des.IV = keyIV

        Dim ms As New MemoryStream
        Dim cs As New CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write)

        Dim sw As New StreamWriter(cs)
        sw.Write(SourceStr)

        sw.Flush()
        cs.FlushFinalBlock()

        ms.Flush()
        EncryptDes = Convert.ToBase64String(ms.GetBuffer(), 0, ms.Length)
    End Function

End Class
