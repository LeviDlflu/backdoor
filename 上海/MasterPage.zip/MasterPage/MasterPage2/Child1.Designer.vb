﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Child1
    Inherits MasterPage2.Parent

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.cmb_Kbn = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("MS UI Gothic", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label29.Location = New System.Drawing.Point(103, 166)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(65, 11)
        Me.Label29.TabIndex = 284
        Me.Label29.Text = "(工程コード)"
        '
        'cmb_Kbn
        '
        Me.cmb_Kbn.AutoCompleteCustomSource.AddRange(New String() {"01：Mﾊﾞｯｸﾄﾞｱ"})
        Me.cmb_Kbn.BackColor = System.Drawing.Color.White
        Me.cmb_Kbn.FormattingEnabled = True
        Me.cmb_Kbn.Location = New System.Drawing.Point(12, 180)
        Me.cmb_Kbn.Name = "cmb_Kbn"
        Me.cmb_Kbn.Size = New System.Drawing.Size(256, 20)
        Me.cmb_Kbn.TabIndex = 282
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("MS UI Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label30.Location = New System.Drawing.Point(9, 163)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(98, 14)
        Me.Label30.TabIndex = 283
        Me.Label30.Text = "Process code"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label7.Location = New System.Drawing.Point(151, 141)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 12)
        Me.Label7.TabIndex = 281
        Me.Label7.Text = "(検索条件)"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 135)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(145, 19)
        Me.Label3.TabIndex = 280
        Me.Label3.Text = "Search criteria"
        '
        'Child1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.ClientSize = New System.Drawing.Size(800, 501)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.cmb_Kbn)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label3)
        Me.Name = "Child1"
        Me.Text = "Child1"
        Me.Controls.SetChildIndex(Me.Label3, 0)
        Me.Controls.SetChildIndex(Me.Label7, 0)
        Me.Controls.SetChildIndex(Me.Label30, 0)
        Me.Controls.SetChildIndex(Me.cmb_Kbn, 0)
        Me.Controls.SetChildIndex(Me.Label29, 0)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label29 As Label
    Friend WithEvents cmb_Kbn As ComboBox
    Friend WithEvents Label30 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label3 As Label
End Class
