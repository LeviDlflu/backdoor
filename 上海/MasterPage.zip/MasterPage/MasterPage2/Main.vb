﻿Public Class Main
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim frm As New Child1()
        frm.ShowDialog()
        Me.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim frm As New Child2()
        frm.ShowDialog()
        Me.Show()
    End Sub
End Class