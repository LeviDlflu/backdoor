﻿Public Class Main
    Public formFlg As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        formFlg = 1
        Dim frm As New Parent()
        frm.ShowDialog()
        Me.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        formFlg = 2
        Dim frm As New Parent()
        frm.ShowDialog()
        Me.Show()
    End Sub
End Class