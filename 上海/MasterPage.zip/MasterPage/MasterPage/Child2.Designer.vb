﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Child2
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmb_HinCd = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmb_Koutei = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmb_Syasyu = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmb_Kbn = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("MS UI Gothic", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label17.Location = New System.Drawing.Point(94, 84)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(37, 11)
        Me.Label17.TabIndex = 137
        Me.Label17.Text = "(車種)"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("MS UI Gothic", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label13.Location = New System.Drawing.Point(315, 40)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(37, 11)
        Me.Label13.TabIndex = 136
        Me.Label13.Text = "(工程)"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("MS UI Gothic", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label10.Location = New System.Drawing.Point(62, 40)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 11)
        Me.Label10.TabIndex = 135
        Me.Label10.Text = "(区分)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label7.Location = New System.Drawing.Point(144, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 12)
        Me.Label7.TabIndex = 134
        Me.Label7.Text = "(検索条件)"
        '
        'cmb_HinCd
        '
        Me.cmb_HinCd.AutoCompleteCustomSource.AddRange(New String() {"01：Mﾊﾞｯｸﾄﾞｱ"})
        Me.cmb_HinCd.BackColor = System.Drawing.Color.White
        Me.cmb_HinCd.FormattingEnabled = True
        Me.cmb_HinCd.Location = New System.Drawing.Point(264, 98)
        Me.cmb_HinCd.Name = "cmb_HinCd"
        Me.cmb_HinCd.Size = New System.Drawing.Size(300, 20)
        Me.cmb_HinCd.TabIndex = 132
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("MS UI Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label8.Location = New System.Drawing.Point(261, 81)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 14)
        Me.Label8.TabIndex = 133
        Me.Label8.Text = "Product name"
        '
        'cmb_Koutei
        '
        Me.cmb_Koutei.AutoCompleteCustomSource.AddRange(New String() {"01：Mﾊﾞｯｸﾄﾞｱ"})
        Me.cmb_Koutei.BackColor = System.Drawing.Color.Yellow
        Me.cmb_Koutei.FormattingEnabled = True
        Me.cmb_Koutei.Location = New System.Drawing.Point(263, 54)
        Me.cmb_Koutei.Name = "cmb_Koutei"
        Me.cmb_Koutei.Size = New System.Drawing.Size(301, 20)
        Me.cmb_Koutei.TabIndex = 130
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.Location = New System.Drawing.Point(261, 37)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 14)
        Me.Label6.TabIndex = 131
        Me.Label6.Text = "Project"
        '
        'cmb_Syasyu
        '
        Me.cmb_Syasyu.AutoCompleteCustomSource.AddRange(New String() {"01：Mﾊﾞｯｸﾄﾞｱ"})
        Me.cmb_Syasyu.BackColor = System.Drawing.Color.White
        Me.cmb_Syasyu.FormattingEnabled = True
        Me.cmb_Syasyu.Location = New System.Drawing.Point(9, 98)
        Me.cmb_Syasyu.Name = "cmb_Syasyu"
        Me.cmb_Syasyu.Size = New System.Drawing.Size(228, 20)
        Me.cmb_Syasyu.TabIndex = 128
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 81)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 14)
        Me.Label5.TabIndex = 129
        Me.Label5.Text = "Vehicle type"
        '
        'cmb_Kbn
        '
        Me.cmb_Kbn.AutoCompleteCustomSource.AddRange(New String() {"01：Mﾊﾞｯｸﾄﾞｱ"})
        Me.cmb_Kbn.BackColor = System.Drawing.Color.White
        Me.cmb_Kbn.FormattingEnabled = True
        Me.cmb_Kbn.Location = New System.Drawing.Point(8, 54)
        Me.cmb_Kbn.Name = "cmb_Kbn"
        Me.cmb_Kbn.Size = New System.Drawing.Size(229, 20)
        Me.cmb_Kbn.TabIndex = 126
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("MS UI Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label16.Location = New System.Drawing.Point(6, 37)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(60, 14)
        Me.Label16.TabIndex = 127
        Me.Label16.Text = "Division"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(1, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(145, 19)
        Me.Label3.TabIndex = 125
        Me.Label3.Text = "Search criteria"
        '
        'Child2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 161)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cmb_HinCd)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cmb_Koutei)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cmb_Syasyu)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cmb_Kbn)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label3)
        Me.Name = "Child2"
        Me.Text = "Child2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label17 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents cmb_HinCd As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents cmb_Koutei As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents cmb_Syasyu As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents cmb_Kbn As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label3 As Label
End Class
