﻿Public Class Parent

    Private Sub Parent_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim childForm As New Form
        Select Case Main.formFlg
            Case 1
                childForm = New Child1
            Case 2
                childForm = New Child2

        End Select

        childForm.FormBorderStyle = FormBorderStyle.None
        childForm.TopLevel = False
        Panel1.Controls.Add(childForm)
        childForm.Show()
    End Sub
End Class
