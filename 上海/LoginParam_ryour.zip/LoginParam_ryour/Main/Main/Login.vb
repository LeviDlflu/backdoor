﻿Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Security.Cryptography
Imports System.Text

Public Class Login
    Dim MF As System.IO.MemoryMappedFiles.MemoryMappedFile

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        MF = System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew("user", 1000)

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try

            Dim str As String = "user:" & Me.TextBox1.Text & ";pwd:" & Me.TextBox2.Text & ";lang:" & Me.ComboBox1.Text


            Dim user As String = Me.TextBox1.Text
            Dim objUed As New System.Text.UTF8Encoding
            Dim buf As Byte() = objUed.GetBytes(str)

            Dim ms As System.IO.MemoryMappedFiles.MemoryMappedViewStream
            ms = MF.CreateViewStream

            ms.Write(buf, 0, buf.Length)

        Catch ex As Exception

        End Try

        Dim frm As New Main()
        frm.ShowDialog()
        Me.Show()

    End Sub

End Class
